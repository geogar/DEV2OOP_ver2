<?php
    class Person {
        //code goes here
    }

    $person1 = new Person; // instance of a class(OBJECT)

    $person2 = new Person; // 2 instances of the Person Class
    

?>


